from flask import Flask, render_template, request, redirect, url_for, session, flash
import psycopg2
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'ваш_секретный_ключ'

# Настройки подключения к PostgreSQL
DATABASE_CONFIG = {
    'dbname': 'audiotech',
    'user': 'postgres',  # Ваш пользователь
    'password': '1234',  # Ваш пароль
    'host': 'localhost',
    'port': 5432
}

def get_db_connection():
    conn = psycopg2.connect(**DATABASE_CONFIG)
    return conn

@app.route('/')
def index():
    if 'username' in session:
        if session['role'] == 'admin':
            return redirect(url_for('admin'))
        else:
            return redirect(url_for('user'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute('SELECT * FROM Users WHERE username = %s AND password = %s', (username, password))
        user = cur.fetchone()
        cur.close()
        conn.close()
        if user:
            session['username'] = user[1]
            session['user_id'] = user[0]
            session['role'] = user[3]
            return redirect(url_for('index'))
        else:
            flash('Неверное имя пользователя или пароль', 'error')
    return render_template('login.html')

@app.route('/admin')
def admin():
    if 'username' in session and session['role'] == 'admin':
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute('SELECT * FROM AudioFiles')
        audio_files = cur.fetchall()
        cur.execute('SELECT * FROM Genres')
        genres = cur.fetchall()
        cur.close()
        conn.close()
        return render_template('admin.html', audio_files=audio_files, genres=genres)
    return redirect(url_for('login'))

@app.route('/user')
def user():
    if 'username' in session and session['role'] == 'user':
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute('SELECT * FROM AudioFiles')
        audio_files = cur.fetchall()
        cur.execute('SELECT * FROM Genres')
        genres = cur.fetchall()
        cur.close()
        conn.close()
        return render_template('user.html', audio_files=audio_files, genres=genres)
    return redirect(url_for('login'))

@app.route('/add_audio', methods=['GET', 'POST'])
def add_audio():
    if 'username' in session and session['role'] == 'admin':
        if request.method == 'POST':
            title = request.form['title']
            artist = request.form['artist']
            album = request.form['album']
            file_path = request.form['file_path']
            file_url = request.form['file_url']
            conn = get_db_connection()
            cur = conn.cursor()
            cur.execute(
                'INSERT INTO AudioFiles (title, artist, album, file_path, uploaded_by, file_url) VALUES (%s, %s, %s, %s, %s, %s)',
                (title, artist, album, file_path, session['user_id'], file_url)
            )
            conn.commit()
            cur.close()
            conn.close()
            flash('Аудиозапись успешно добавлена', 'success')
            return redirect(url_for('admin'))
        return render_template('add_audio.html')
    return redirect(url_for('login'))

@app.route('/add_genre', methods=['GET', 'POST'])
def add_genre():
    if 'username' in session and session['role'] == 'admin':
        if request.method == 'POST':
            name = request.form['name']
            conn = get_db_connection()
            cur = conn.cursor()
            cur.execute('INSERT INTO Genres (name) VALUES (%s)', (name,))
            conn.commit()
            cur.close()
            conn.close()
            flash('Жанр успешно добавлен', 'success')
            return redirect(url_for('admin'))
        return render_template('add_genre.html')
    return redirect(url_for('login'))

@app.route('/search', methods=['GET'])
def search():
    if 'username' in session:
        query = request.args.get('query', '')
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute('''
            SELECT * FROM AudioFiles
            WHERE title ILIKE %s OR artist ILIKE %s OR album ILIKE %s
        ''', (f'%{query}%', f'%{query}%', f'%{query}%'))
        results = cur.fetchall()
        cur.close()
        conn.close()
        return render_template('search.html', results=results, query=query)
    return redirect(url_for('login'))

@app.route('/audio/<int:audio_id>', methods=['GET', 'POST'])
def audio_detail(audio_id):
    if 'username' in session:
        back_url = request.args.get('back_url', url_for('user'))

        conn = get_db_connection()
        cur = conn.cursor()

        # Получаем данные об аудиозаписи
        cur.execute('SELECT * FROM AudioFiles WHERE id = %s', (audio_id,))
        audio = cur.fetchone()

        # Получаем количество лайков
        cur.execute('SELECT COUNT(*) FROM Likes WHERE audio_id = %s', (audio_id,))
        likes_count = cur.fetchone()[0]

        # Получаем комментарии
        cur.execute('SELECT * FROM Comments WHERE audio_id = %s ORDER BY created_at DESC', (audio_id,))
        comments = cur.fetchall()

        # Обработка лайков и комментариев
        if request.method == 'POST':
            if 'like' in request.form:
                cur.execute('INSERT INTO Likes (audio_id, user_id) VALUES (%s, %s)', (audio_id, session['user_id']))
                conn.commit()
                flash('Лайк успешно поставлен', 'success')
            elif 'comment' in request.form:
                text = request.form['comment']
                cur.execute('INSERT INTO Comments (audio_id, user_id, text) VALUES (%s, %s, %s)', (audio_id, session['user_id'], text))
                conn.commit()
                flash('Комментарий успешно добавлен', 'success')

        cur.close()
        conn.close()

        return render_template('audio_detail.html', audio=audio, likes_count=likes_count, comments=comments)
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Проверка, что пользователь не администратор
        if 'role' in request.form and request.form['role'] == 'admin':
            flash('Регистрация администратора запрещена', 'error')
            return redirect(url_for('register'))

        conn = get_db_connection()
        cur = conn.cursor()

        # Проверка, что пользователь с таким именем не существует
        cur.execute('SELECT * FROM Users WHERE username = %s', (username,))
        existing_user = cur.fetchone()

        if existing_user:
            flash('Пользователь с таким именем уже существует', 'error')
            cur.close()
            conn.close()
            return redirect(url_for('register'))

        # Регистрация нового пользователя с ролью 'user'
        cur.execute('INSERT INTO Users (username, password, role) VALUES (%s, %s, %s)', (username, password, 'user'))
        conn.commit()
        cur.close()
        conn.close()

        flash('Регистрация прошла успешно. Теперь вы можете войти.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/create_admin', methods=['GET', 'POST'])
def create_admin():
    if 'username' in session and session['role'] == 'admin':
        if request.method == 'POST':
            username = request.form['username']
            password = request.form['password']

            conn = get_db_connection()
            cur = conn.cursor()

            # Проверка, что пользователь с таким именем не существует
            cur.execute('SELECT * FROM Users WHERE username = %s', (username,))
            existing_user = cur.fetchone()

            if existing_user:
                flash('Пользователь с таким именем уже существует', 'error')
                cur.close()
                conn.close()
                return redirect(url_for('create_admin'))

            # Создание администратора
            cur.execute('INSERT INTO Users (username, password, role) VALUES (%s, %s, %s)', (username, password, 'admin'))
            conn.commit()
            cur.close()
            conn.close()

            flash('Администратор успешно создан', 'success')
            return redirect(url_for('admin'))

        return render_template('create_admin.html')
    return redirect(url_for('login'))

@app.route('/playlists')
def playlists():
    if 'username' in session:
        conn = get_db_connection()
        cur = conn.cursor()

        # Получаем плейлисты пользователя
        cur.execute('SELECT * FROM Playlists WHERE user_id = %s', (session['user_id'],))
        playlists = cur.fetchall()

        cur.close()
        conn.close()

        return render_template('playlists.html', playlists=playlists)
    return redirect(url_for('login'))

@app.route('/add_playlist', methods=['GET', 'POST'])
def add_playlist():
    if 'username' in session:
        if request.method == 'POST':
            name = request.form['name']
            conn = get_db_connection()
            cur = conn.cursor()
            cur.execute('INSERT INTO Playlists (name, user_id) VALUES (%s, %s)', (name, session['user_id']))
            conn.commit()
            cur.close()
            conn.close()
            flash('Плейлист успешно создан', 'success')
            return redirect(url_for('playlists'))
        return render_template('add_playlist.html')
    return redirect(url_for('login'))

@app.route('/playlist/<int:playlist_id>', methods=['GET', 'POST'])
def playlist_detail(playlist_id):
    if 'username' in session:
        conn = get_db_connection()
        cur = conn.cursor()

        # Получаем данные о плейлисте
        cur.execute('SELECT * FROM Playlists WHERE id = %s', (playlist_id,))
        playlist = cur.fetchone()

        # Получаем аудиозаписи в плейлисте
        cur.execute('''
            SELECT af.id, af.title, af.artist, af.album
            FROM AudioFiles af
            JOIN PlaylistAudio pa ON af.id = pa.audio_id
            WHERE pa.playlist_id = %s
        ''', (playlist_id,))
        audio_files = cur.fetchall()

        # Получаем все аудиозаписи для выпадающего списка
        cur.execute('SELECT id, title, artist FROM AudioFiles')
        all_audio = cur.fetchall()

        # Добавление трека в плейлист
        if request.method == 'POST':
            audio_id = request.form['audio_id']
            cur.execute('INSERT INTO PlaylistAudio (playlist_id, audio_id) VALUES (%s, %s)', (playlist_id, audio_id))
            conn.commit()
            flash('Трек успешно добавлен в плейлист', 'success')
            return redirect(url_for('playlist_detail', playlist_id=playlist_id))

        cur.close()
        conn.close()

        return render_template('playlist_detail.html', playlist=playlist, audio_files=audio_files, all_audio=all_audio)
    return redirect(url_for('login'))

@app.route('/logout')
def logout():
    session.pop('username', None)
    session.pop('user_id', None)
    session.pop('role', None)
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)